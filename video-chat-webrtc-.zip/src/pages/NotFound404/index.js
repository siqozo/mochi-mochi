export default function NotFound404() {
  return (
    <div>
      NOT FOUND.
    </div>
  );
}